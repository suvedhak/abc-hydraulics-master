import * as types from '../types/type';

export const addProduct = (payload) => ({
    type:types.Add_PRODUCT,
    payload
})

