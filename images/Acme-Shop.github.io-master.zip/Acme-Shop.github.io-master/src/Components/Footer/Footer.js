const Footer = () => {
    return ( 
        <>
        <div style={{"height":"100px","backgroundColor":"#222"
        ,marginTop:'50px'}}></div>
        </>
     );
}
 
export default Footer;
