const Donation = () => {
    return ( <>
    <h1>Donation Page</h1>
    </> );
}
 
export default Donation;