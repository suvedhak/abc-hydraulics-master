export const addItemToCart = (payload) => ({

    type: "ADD_PRODUCT",
    payload
})
